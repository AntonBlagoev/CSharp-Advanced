﻿using System;

namespace _07.Tuple
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] firstLine = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] secondLine = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] thirdLine = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            Tuple<string, string> firstTuple = new Tuple<string, string>($"{firstLine[0]} {firstLine[1]}", firstLine[2]);
            Tuple<string, int> secondTuple = new Tuple<string, int>(secondLine[0], int.Parse(secondLine[1]));
            Tuple<int, double> thirdTuple = new Tuple<int, double>(int.Parse(thirdLine[0]), double.Parse(thirdLine[1]));

            Console.WriteLine(firstTuple);
            Console.WriteLine(secondTuple);
            Console.WriteLine(thirdTuple);

        }
    }
}
