﻿using System;

namespace _02.Collection
{
    class Program
    {
        public static void Main(string[] args)
        {
            ListyIterator<string> myList = new ListyIterator<string>();
            string command = string.Empty;
            while ((command = Console.ReadLine()) != "END")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);


                if (tokens[0] == "Create")
                {
                    if (tokens.Length > 0)
                    {
                        for (int i = 1; i < tokens.Length; i++)
                        {
                            myList.Add(tokens[i]);
                        }
                    }
                }
                else if (tokens[0] == "Move")
                {
                    Console.WriteLine(myList.Move());
                }
                else if (tokens[0] == "HasNext")
                {
                    Console.WriteLine(myList.HasNext());
                }
                else if (tokens[0] == "Print")
                {
                    try
                    {
                        myList.Print();
                    }
                    catch (InvalidOperationException exception)
                    {
                        Console.WriteLine(exception.Message);
                    }
                }

                else if (tokens[0] == "PrintAll")
                {
                    foreach (var item in myList)
                    {
                        Console.Write($"{item} ");
                    }
                    Console.WriteLine();
                }

            }
        }
    }
}
