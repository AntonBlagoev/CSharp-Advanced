﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.ListyIterator
{
    public class ListyIterator<T>
    {
        private List<T> items;
        private int index;
        public ListyIterator()
        {
            this.items = new List<T>();
        }
        public int Count { get; private set; }

        public void Add(T item)
        {
            items.Add(item);
            this.Count++;
        }
        public  bool Move()
        {
            if (this.index == this.Count - 1)
            {
                return false;
            }
            index++;
            return true;
        }
        public bool HasNext()
        {
            if (this.index == this.Count - 1)
            {
                return false;
            }
            return true;

        }
        public void Print()
        {
            if (this.Count == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }

            Console.WriteLine($"{this.items[this.index]}");

        }

    }
}
